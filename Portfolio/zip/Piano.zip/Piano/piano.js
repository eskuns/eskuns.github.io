// Création d'un objet contenant les correspondances entre les touches du piano et les fichiers audio
var pianoSounds = {
    'do': 'sounds/c.wav',
    's': 'sounds/c.wav',

    're': 'sounds/d.wav',
    'd': 'sounds/d.wav',

    'mi': 'sounds/e.wav',
    'f': 'sounds/e.wav',

    'fa': 'sounds/f.wav',
    'g': 'sounds/f.wav',

    'sol': 'sounds/g.wav',
    'h': 'sounds/g.wav',

    'la': 'sounds/a.wav',
    'j': 'sounds/a.wav',

    'si': 'sounds/b.wav',
    'k': 'sounds/b.wav',

    'do-diese': 'sounds/cs.wav',
    'e': 'sounds/cs.wav',
 
    're-diese': 'sounds/ds.wav',
    'r': 'sounds/ds.wav',

    'fa-diese': 'sounds/fs.wav',
    'y': 'sounds/fs.wav',

    'sol-diese': 'sounds/gs.wav',
    'u': 'sounds/gs.wav',

    'la-diese': 'sounds/as.wav',
    'i': 'sounds/as.wav'


};

// Fonction pour jouer un son en fonction de la touche cliquée
function playSound(note) {
    var audio = new Audio(pianoSounds[note]);
    audio.volume = 0.5; // Réglez le volume comme vous le souhaitez
    audio.play();
}

// Ajoutez un écouteur d'événements pour le clic sur les touches du piano
document.querySelectorAll('.becarre, .diese').forEach(function (key) {
    key.addEventListener('click', function () {
        var note = key.id;
        playSound(note);
    });
});






// Ajoutez un écouteur d'événements pour la pression des touches du clavier
document.addEventListener('keydown', function (event) {
    var key = event.key.toLowerCase();
    playSound(key);

    if (key === 's') {
        document.querySelector('.do').classList.add('red');
    }
    if (key === 'd') {
        document.querySelector('.re').classList.add('red');
    }
    if (key === 'f') {
        document.querySelector('.mi').classList.add('red');
    }
    if (key === 'g') {
        document.querySelector('.fa').classList.add('red');
    }
    if (key === 'h') {
        document.querySelector('.sol').classList.add('red');
    }
    if (key === 'j') {
        document.querySelector('.la').classList.add('red');
    }
    if (key === 'k') {
        document.querySelector('.si').classList.add('red');
    }
    if (key === 'e') {
        document.querySelector('.diese.do').classList.add('red');
    }
    if (key === 'r') {
        document.querySelector('.diese.re').classList.add('red');
    }
    if (key === 'y') {
        document.querySelector('.diese.fa').classList.add('red');
    }
    if (key === 'u') {
        document.querySelector('.diese.sol').classList.add('red');
    }
    if (key === 'i') {
        document.querySelector('.diese.la').classList.add('red');
        }
});

// Ajoutez un écouteur d'événements pour le relâchement des touches du clavier
document.addEventListener('keyup', function (event) {
    var key = event.key.toLowerCase();

    // Remettez la couleur initiale de la première touche si la touche "s" est relâchée
    if (key === 's') {
        document.querySelector('.do').classList.remove('red');
    }
    if (key === 'd') {
        document.querySelector('.re').classList.remove('red');
    }
    if (key === 'f') {
        document.querySelector('.mi').classList.remove('red');
    }
    if (key === 'g') {
        document.querySelector('.fa').classList.remove('red');
    }
    if (key === 'h') {
        document.querySelector('.sol').classList.remove('red');
    }
    if (key === 'j') {
        document.querySelector('.la').classList.remove('red');
    }
    if (key === 'k') {
        document.querySelector('.si').classList.remove('red');
    }
    if (key === 'e') {
        document.querySelector('.diese.do').classList.remove('red');
    }
    if (key === 'r') {
        document.querySelector('.diese.re').classList.remove('red');
    }
    if (key === 'y') {
        document.querySelector('.diese.fa').classList.remove('red');
    }
    if (key === 'u') {
        document.querySelector('.diese.sol').classList.remove('red');
    }
    if (key === 'i') {
        document.querySelector('.diese.la').classList.remove('red');
        }
});


